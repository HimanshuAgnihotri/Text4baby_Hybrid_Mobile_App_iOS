//var isiPhone = /iphone/i.test(navigator.userAgent.toLowerCase());

if (navigator.userAgent.match(/iPhone/i) == 'iPhone') {
    // do nothing
    //alert('is iphone');
}
else {
    //alert('not an iphone');
    $('#a1').attr("onclick", "window.open('http://www.cdc.gov/vaccines/schedules/easy-to-read/child.html','_system','location=yes,enableViewportScale=yes')").trigger('create');
    //alert($('#a1').attr('onclick'));
    $('#a2').attr("onclick", "window.open('http://www.safercar.gov/cpsApp/cps/index.htm','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a3').attr("onclick", "window.open('https://www.rsvprotection.com/rsv-risk-assessment.html','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a4').attr("onclick", "window.open('http://www.saferproducts.gov/Default.aspx','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a5').attr("onclick", "window.open('http://www.nhtsa.gov/cpsfitting/index.cfm','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a6').attr("onclick", "window.open('http://m.usfa.fema.gov/mobile','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a7').attr("onclick", "window.open('http://www.aapcc.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a8').attr("onclick", "window.open('http://www.thehotline.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a9').attr("onclick", "window.open('http://www.childcareaware.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a10').attr("onclick", "window.open('http://www.whyhunger.org/findfood','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a11').attr("onclick", "window.open('http://www.postpartum.net/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a12').attr("onclick", "window.open('http://smokefree.gov/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a13').attr("onclick", "window.open('http://www.samhsa.gov/treatment/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a14').attr("onclick", "window.open('http://www.infantsee.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a15').attr("onclick", "window.open('http://m.insurekidsnow.gov/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a16').attr("onclick", "window.open('http://www.cdc.gov/vaccines/programs/vfc/index.html','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a17').attr("onclick", "window.open('http://www.thehotline.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a18').attr("onclick", "window.open('http://www.childcareaware.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a19').attr("onclick", "window.open('http://www.whyhunger.org/findfood','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a20').attr("onclick", "window.open('http://www.postpartum.net/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a21').attr("onclick", "window.open('http://smokefree.gov/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a22').attr("onclick", "window.open('http://www.samhsa.gov/treatment/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a23').attr("onclick", "window.open('http://m.insurekidsnow.gov/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a24').attr("onclick", "window.open('http://www.cdc.gov/vaccines/programs/vfc/index.html','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a25').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a26').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a27').attr("onclick", "window.open('https://text4baby.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a28').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a29').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a30').attr("onclick", "window.open('https://www.jnj.com/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a31').attr("onclick", "window.open('https://www.facebook.com/text4baby','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a32').attr("onclick", "window.open('https://twitter.com/#!/mytext4baby','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a33').attr("onclick", "window.open('https://text4baby.org/index.php/about/partners/2-uncategorised/107','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a34').attr("onclick", "window.open('https://text4baby.org/index.php/about/partners/2-uncategorised/107','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a35').attr("onclick", "window.open('https://text4baby.org/index.php/about/partners/2-uncategorised/108','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a36').attr("onclick", "window.open('https://text4baby.org/index.php/about/partners/102','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a37').attr("onclick", "window.open('https://text4baby.org/index.php/about/partners/2-uncategorised/101','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a38').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a39').attr("onclick", "window.open('https://text4baby.org/','_system','location=yes,enableViewportScale=yes')").trigger('create');
    $('#a40').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a41').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a42').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');
    $('#a43').attr("onclick", "window.location='mailto:info@text4baby.org','_system','location=yes,enableViewportScale=yes'; return false;").trigger('create');

}
